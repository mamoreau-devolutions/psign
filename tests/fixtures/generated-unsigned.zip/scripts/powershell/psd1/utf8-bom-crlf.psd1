﻿@{
    RootModule = 'vector.psm1'
}
