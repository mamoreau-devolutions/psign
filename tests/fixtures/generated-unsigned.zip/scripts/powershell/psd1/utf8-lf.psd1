@{
    RootModule = 'vector.psm1'
}
