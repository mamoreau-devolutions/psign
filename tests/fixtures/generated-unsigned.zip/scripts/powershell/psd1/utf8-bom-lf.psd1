﻿@{
    RootModule = 'vector.psm1'
}
