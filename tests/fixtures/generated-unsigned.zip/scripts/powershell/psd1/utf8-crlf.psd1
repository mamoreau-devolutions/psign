@{
    RootModule = 'vector.psm1'
}
